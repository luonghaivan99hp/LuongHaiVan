package backend.respostory;

public interface UserInterface {

    void registerManager();
    void registerEmployee();
    void login();
    boolean isGmailAddress(String email);
    public String checkExistEmail();
}

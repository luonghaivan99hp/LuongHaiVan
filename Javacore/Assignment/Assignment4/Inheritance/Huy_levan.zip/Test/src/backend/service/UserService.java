package backend.service;

import backend.respostory.UserInterface;
import backend.respostory.UserRepostory;
import entity.Employee;
import entity.Manager;
import entity.User;

import java.util.ArrayList;
import java.util.List;
import java.util.Scanner;
import java.util.regex.Matcher;
import java.util.regex.Pattern;


public class UserService implements UserServiceInterface {
    private UserInterface userInterface;
    public UserService() {
        userInterface = new UserRepostory();
    }

    @Override
    public void registerManager() {
        userInterface.registerManager();
    }

    @Override
    public void registerEmployee() {
       userInterface.registerEmployee();
    }

    @Override
    public void login() {
        userInterface.login();
    }

    @Override
    public boolean isGmailAddress(String email) {
        return isGmailAddress(email);
    }

    @Override
    public String checkExistEmail() {
        return checkExistEmail();
    }


}

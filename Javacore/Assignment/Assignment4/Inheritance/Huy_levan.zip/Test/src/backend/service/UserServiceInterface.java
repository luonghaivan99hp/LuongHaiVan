package backend.service;

public interface UserServiceInterface {
     void registerManager();
     void registerEmployee();
     void login();
     boolean isGmailAddress(String email);
     public String checkExistEmail();

}

package backend.controller;

import backend.service.UserService;
import backend.service.UserServiceInterface;

public class Controller {
   private UserServiceInterface anInterface;

    public Controller() {
        anInterface = new UserService();
    }
   public void registerManager(){
       anInterface.registerManager();
   }
    public void registerEmployee(){
        anInterface.registerEmployee();
    }
    public void login(){
        anInterface.login();
    }
}

package backend.respostory;

import entity.Employee;
import entity.Manager;
import entity.User;

import java.util.ArrayList;
import java.util.List;
import java.util.Scanner;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

public class UserRepostory implements UserInterface{
    Scanner sc = new Scanner(System.in);

    @Override
    public void registerManager() {

        System.out.print("Nhập số bản ghi muốn thêm: ");
        List<Manager> managerList = new ArrayList<>();
        int count = Integer.parseInt(sc.nextLine());
        for (int i = 0; i < count; i++) {
            System.out.print("Enter Firstname: ");
            String firstname = sc.nextLine();
            System.out.print("Enter Lastname: ");
            String lastname = sc.nextLine();
            System.out.println("Số điện thoại phải từ 9 đến 12 số");
            System.out.print("Enter Phone: ");
            String phoneNumber = sc.nextLine();
            if (phoneNumber.length() >= 9 && phoneNumber.length() <= 12) {
                System.out.print("Correct Value! \n");
            } else {
                System.out.print("Incorrect Value! \n");
                return;
            }
            System.out.println("Email phải có đuôi @vti.com.vn");
            System.out.print("Enter your email: ");
            String email = sc.nextLine();
            if (isGmailAddress(email)) {
                System.out.println("Correct Email! \n");
            } else {
                System.out.println("Incorrect email! \n");
                return;
            }
            System.out.print("Enter expInYear");
            int year = Integer.parseInt(sc.nextLine());
            Manager manager = new Manager(firstname, lastname, phoneNumber, email, year);
            managerList.add(manager);
            for (Manager mng: managerList
            ) {
                System.out.println(mng.toString());
            }

        }
    }
    @Override
    public void registerEmployee() {
        System.out.print("Nhập số bản ghi muốn thêm: ");
        int count = Integer.parseInt(sc.nextLine());
        for (int i = 0; i < count; i++) {
            System.out.print("Enter Firstname: ");
            String firstname = sc.nextLine();
            System.out.print("Enter Lastname: ");
            String lastname = sc.nextLine();
            System.out.println("Số điện thoại phải từ 9 đến 12 số");
            System.out.print("Enter Phone: ");
            String phoneNumber = sc.nextLine();
            if (phoneNumber.length() >= 9 && phoneNumber.length() <= 12) {
                System.out.print("Correct Value! \n");
            } else {
                System.out.print("Incorrect Value! \n");
                return;
            }
            System.out.println("Email phải có đuôi @vti.com.vn");
            System.out.print("Enter your email: ");
            String email = sc.nextLine();
            if (isGmailAddress(email)) {
                System.out.println("Correct Email! \n");
            } else {
                System.out.println("Incorrect email! \n");
                return;
            }
            System.out.print("Enter ProjectName: ");
            String projectName = sc.nextLine();
            System.out.print("Enter ProSkill: ");
            String proSkill = sc.nextLine();
            List<Employee> employeeList = new ArrayList<>();
            Employee employee = new Employee(firstname, lastname, phoneNumber, email, projectName, proSkill);
            employeeList.add(employee);
            for (Employee epl : employeeList) {
                System.out.println(epl.toString());
            }
        }
    }

    @Override
    public void login() {
        List<User> users = new ArrayList<>();
        System.out.println("Chức năng đăng nhập: ");
        System.out.print("Nhập email: ");
        String email = sc.nextLine();

            if (isGmailAddress(email)){
                System.out.println("Email correct");
            }
            else {
                System.out.println("Email does not exist");
                return;
            }


            System.out.print("Nhập password: ");
            String password = sc.nextLine();
            if (password.length() > 6 && password.length() < 12 && password.matches(".*[A-Z].*")) {
                System.out.println("Password correct !");
            } else {
                System.out.println("Password incorrect!");
                System.out.println("Password phải có từ 6 đến 12 kí tự và có ít nhất 1 chữ hoa");
                return;
            }
            System.out.println("Đăng nhập thành công");
        }

    @Override
    public boolean isGmailAddress(String email) {
        String expression = "^[\\w.+\\-]+@vti\\.com\\.vn$";
        CharSequence inputStr = email;
        Pattern pattern = Pattern.compile(expression, Pattern.CASE_INSENSITIVE);
        Matcher matcher = pattern.matcher(inputStr);
        return matcher.matches();
    }

    @Override
    public String checkExistEmail() {
        return null;
    }


}

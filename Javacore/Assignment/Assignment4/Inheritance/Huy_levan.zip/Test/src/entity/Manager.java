package entity;

import entity.User;

public class Manager extends User {
private int expInYear;

    public Manager(int expInYear) {
        this.expInYear = expInYear;
    }

    public Manager(String firstName, String lastName, String phone, String email, int expInYear) {
        super(firstName, lastName, phone, email);
        this.expInYear = expInYear;
    }

    public int getExpInYear() {
        return expInYear;
    }

    public void setExpInYear(int expInYear) {
        this.expInYear = expInYear;
    }
}

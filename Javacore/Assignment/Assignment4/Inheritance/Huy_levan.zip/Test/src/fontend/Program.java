package fontend;

import backend.controller.Controller;

import java.util.Scanner;

public class Program {
    public static void main(String[] args) {
        menu();
    }

    public static void menu() {
        Controller service = new Controller();
        while (true) {
            while (true) {
                System.out.println("1. Chức năng thêm Manager");
                System.out.println("2. Chức năng thêm Employee");
                System.out.println("3. Chức năng thêm Login");
                System.out.print("Mời bạn chọn chức năng muốn sử dụng: ");
                Scanner sc = new Scanner(System.in);
                int typing = sc.nextInt();
                switch (typing) {
                    case 1:
                        System.out.println("Chức năng thêm Manager");
                        service.registerManager();
                        break;
                    case 2:
                        System.out.println("CHức năng thêm entity.Employee");
                        service.registerEmployee();
                        break;
                    case 3:
                        System.out.println("CHức năng đăng nhập:  ");
                        service.login();
                        break;
                    default:
                        System.out.println("Mời bạn nhập lại: ");
                }
            }
        }
    }
}
